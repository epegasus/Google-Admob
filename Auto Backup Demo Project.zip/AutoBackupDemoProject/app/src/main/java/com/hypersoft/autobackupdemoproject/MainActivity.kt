package com.hypersoft.autobackupdemoproject

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.hypersoft.autobackupdemoproject.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private val sharedPref: SharedPreferences by lazy { getSharedPreferences("sharedPref", Context.MODE_PRIVATE) }
    private val binding: ActivityMainBinding by lazy { ActivityMainBinding.inflate(layoutInflater) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        setUI()
        binding.btnSave.setOnClickListener { saveDataInSharedPref() }
    }

    private fun setUI() {
        sharedPref.apply {
            binding.etFullName.setText(this.getString("name", ""))
            binding.etContactNumber.setText(this.getString("contact", ""))
            binding.etAddress.setText(this.getString("address", ""))
        }
    }

    private fun saveDataInSharedPref() {
        sharedPref.edit().apply{
            this.putString("name", binding.etFullName.text.toString())
            this.putString("contact", binding.etContactNumber.text.toString())
            this.putString("address", binding.etAddress.text.toString())
            this.apply()
            Toast.makeText(this@MainActivity, "Info Saved!", Toast.LENGTH_SHORT).show()
        }
    }

}